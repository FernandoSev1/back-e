//rutas para registro
const express = require("express");
const router = express.Router();
const registroController = require("../controllers/registroController");

//api/ registro
router.post("/", registroController.crearRegistro);

module.exports = router;
