const { request } = require("express");
const Registro = require("../models/Registro");
const { param } = require("../routes/registro");

exports.crearRegistro = async (req, res) =>{
    try {
        let registro;

        //creamos registro
        registro = new Registro(req.body);

       await registro.save();
       res.send(registro);


    } catch (error) {
        console.log(error);
        res.status(500).send("Ha ocurrido un error")
    }
}

exports.obtenerRegistros = async (req, res) =>{

    try {
        
        const registros = await Registro.find();
        res.json(registros)

    } catch (error) {
        console.log(error);
        res.status(500).send("Ha ocurrido un error")
    }
}

exports.actualizarRegistros = async (req, res) => {
    try {
        const {nombre, apellidoPaterno, apellidoMaterno, edad, genero} = req.body;
        let registro = await Registro.findById(req.params.id);

        if(!registro){
            res.status(404).json({msg: "NO existe el registro"})
        }

        registro.nombre = nombre;

        registro = await Registro.findOneAndUpdate({ _id: req.params.id}, registro, {new:true})
        res.json(registro);
        
    } catch (error) {
        console.log(error);
        res.status(500).send("Ha ocurrido un error")
    }
}

exports.obtenerRegistro = async (req, res) => {
    try {
        let registro = await Registro.findById(req.params.id);

        if(!registro){
            res.status(404).json({msg: "NO existe el registro"})
        }


        registro = await Registro.findOneAndUpdate({ _id: req.params.id}, registro, {new:true})
        res.json(registro);
        
    } catch (error) {
        console.log(error);
        res.status(500).send("Ha ocurrido un error")
    }
}