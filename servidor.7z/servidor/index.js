const express = require("express");
const conectarDB = require("./config/db");

//crear server
const app = express();

//conecta base de datos pa
conectarDB();

app.use(express.json());

app.use("/api/registro", require("./routes/registro"));



app.listen(4000, () => {
    console.log("el servidor está corriendo")
})