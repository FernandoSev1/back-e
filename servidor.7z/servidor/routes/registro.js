//rutas para registro
const express = require("express");
const router = express.Router();
const registroController = require("../controllers/registroController");

//api/ registro
router.post("/", registroController.crearRegistro);
router.get("/", registroController.obtenerRegistros);
router.put("/:id", registroController.actualizarRegistros);
router.get("/:id", registroController.obtenerRegistro);

module.exports = router;
